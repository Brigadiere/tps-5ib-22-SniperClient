using System.Net.Sockets;
using System.Net;
using System.Text;

namespace Brigati_SniperClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Visible = false;
        }
        class mossa
        {
            private int mov_laterale;
            private int mov_vert;
            public int inc_laterale(int mov_laterale)
            {
                mov_laterale += 22;
                return mov_laterale;
            }
            public int inc_vert(int mov_vert)
            {
                mov_vert += 22;
                return mov_vert;
            }
            public int dec_laterale(int mov_laterale)
            {
                mov_laterale -= 22;
                return mov_laterale;
            }
            public int dec_vert(int mov_vert)
            {
                mov_vert -= 22;
                return mov_vert;
            }
        }
        mossa m; 
        int y,x;
        private void button1_Click(object sender, EventArgs e)
        {
            y = m.inc_vert(mov_vert);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            x = m.inc_laterale(mov_laterale);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
            void Connetti()
            { 
                byte[] bytes = new byte[1024];

                try
                {

                    IPAddress ipAddress = System.Net.IPAddress.Parse("127.0.0.1");
                    IPEndPoint remoteEP = new IPEndPoint(ipAddress, 5000);

                    Socket sender = new Socket(ipAddress.AddressFamily,
                        SocketType.Stream, ProtocolType.Tcp);

                    try
                    {
                        sender.Connect(remoteEP);

                        Console.WriteLine("Socket connected to {0}",
                        sender.RemoteEndPoint.ToString());


                        byte[] msg = Encoding.ASCII.GetBytes("This is a test<EOF>");

  
                        int bytesSent = sender.Send(msg);

 
                        int bytesRec = sender.Receive(bytes);
                        Console.WriteLine("Echoed test = {0}",
                            Encoding.ASCII.GetString(bytes, 0, bytesRec));

 
                        sender.Shutdown(SocketShutdown.Both);
                        sender.Close();

                    }
                    catch (ArgumentNullException ane)
                    {
                        Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
                    }
                    catch (SocketException se)
                    {
                        Console.WriteLine("SocketException : {0}", se.ToString());
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Unexpected exception : {0}", e.ToString());
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                
                Console.WriteLine("Premere un tasto per continuare ");
                Console.ReadLine();
                MessageBox.Show("Connesso");
            }
            Connetti();
            /*notifyIcon1.Icon = SystemIcons.Application;
            notifyIcon1.BalloonTipText = "Connesso";
            notifyIcon1.ShowBalloonTip(2000);*/
        }

        private void button7_Click(object sender, EventArgs e)
        {
            /*notifyIcon1.Icon = SystemIcons.Application;
            notifyIcon1.BalloonTipText = textBox1.Text;
            notifyIcon1.ShowBalloonTip(2000);*/
            MessageBox.Show(textBox1.Text);
            textBox1.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            y = m.dec_vert(mov_vert);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            x = m.dec_laterale(mov_laterale);
        }
    }
}