using System.Net.Sockets;
using System.Net;
using System.Text;

namespace Brigati_SniperServer
{
    public partial class Form1 : Form
    {
        public static string data = null;
        public Form1()
        {
            InitializeComponent();
        }
        class punteggio
        {
            private int tentativi = 3;
            private int punteggio_tiro;
            private int punteggio_partita;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            void Inizia_ascolto()
            {
 
                byte[] bytes = new Byte[1024];

                IPAddress ipAddress = System.Net.IPAddress.Parse("127.0.0.1");
                IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 5000);

  
                Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);
                 
                try
                {
                    listener.Bind(localEndPoint);
                    listener.Listen(10);
  
                    while (true)
                    {
                        Console.WriteLine("Waiting for a connection...");

                        Socket handler = listener.Accept();
                        data = textBox1.Text;

                        while (true)
                        {
                            int bytesRec = handler.Receive(bytes);
                            data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                            if (data.IndexOf("<EOF>") > -1)
                            {
                                break;
                            }
                        }

                        Console.WriteLine("Text received : {0}", data);
                          
                        byte[] msg = Encoding.ASCII.GetBytes(data);

                        handler.Send(msg);
                        handler.Shutdown(SocketShutdown.Both);
                        handler.Close();
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                Inizia_ascolto();
                Console.WriteLine("\nPress ENTER to continue...");
                Console.Read();
            }
            /*notifyIcon1.Icon = SystemIcons.Application;
            notifyIcon1.BalloonTipText = "Connesso";
            notifyIcon1.ShowBalloonTip(2000);*/
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*notifyIcon1.Icon = SystemIcons.Application;
            notifyIcon1.BalloonTipText = textBox1.Text;
            notifyIcon1.ShowBalloonTip(2000);*/
            MessageBox.Show(textBox1.Text);
            textBox1.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}